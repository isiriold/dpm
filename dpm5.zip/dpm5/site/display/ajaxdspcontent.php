<?php

$content=""; 
$typecode="";

echo displayContentByType( $content, $typecode );
?>