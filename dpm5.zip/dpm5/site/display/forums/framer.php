<iframe src="?TASK=FORUMSHOW" style="width: 200%; height: 800px;">

</iframe>