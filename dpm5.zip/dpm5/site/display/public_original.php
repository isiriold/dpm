


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">

<body class="home">

<!-- Layout -->
 
            <div id="node-2907" class="node">
    <div class="content clear-block">
    <div id="coastline">
	<div class="content">
		<h1>Connect and Collaborate with the Online Network established by Pharma-X Company, Exclusive to Physicians</h1>
		<ul class="callout-list">
			<li class="first discuss">
				<dl>
					<dt>Discuss</dt>
					<dd>Post and comment to share insights and learn from colleagues</dd>
				</dl>
			</li>
			
			<li class="curbside">
				<dl>
					<dt>Curbside</dt>
					<dd>Solicit input and help peers on challenging patient cases</dd>
				</dl>
			</li>
			
			<li class="first informed">
				<dl>
					<dt>Stay Informed</dt>
					<dd>Follow topics from practice management to healthcare reform</dd>
				</dl>
			</li>
			
			<li class="honoraria">
				<dl>
					<dt>Earn Honoraria</dt>
					<dd>Get paid to participate in surveys and focus groups</dd>
				</dl>
			</li>
		</ul>
	</div>
	
  </body>
</html>
