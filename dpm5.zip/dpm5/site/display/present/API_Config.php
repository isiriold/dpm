<?PHP

/*!
* OpenTok PHP Library
* http://www.tokbox.com/
*
* Copyright 2010, TokBox, Inc.
*
*/

class API_Config {

	// Replace this value with your TokBox API Partner Key
	const API_KEY = "5067991";

	// Replace this value with your TokBox API Partner Secret
	const API_SECRET = "6442542e79d43ff98e37ff1866b94302263648c1";

	const API_SERVER = "https://staging.tokbox.com/hl";
	// Uncomment this line when you launch your app
	// const API_SERVER = "https://api.opentok.com/hl";


	const SDK_VERSION = "tbphp-v0.91.2011-08-26";

}
