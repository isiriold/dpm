<?php

include ("./report_user.php");

include ("./report_specialty.php");


?>

<html>


<div align="center">

<p class="rptText"> Activity for Dr. Emily Johnson from Jan-Jul 2011 </p>

<img src="./report1.png" height="400 px"  width="800 px" align="middle" alt="report1">

</div>

<br/>
<hr>

<p> Activity for Dr. Emily Johnson from Jan-Jul 2011 </p>

<div align="center">

<img src="./report2.png" height="400 px"  width="800 px" alt="report2">

</div>


</html>