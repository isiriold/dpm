<?php
$ENGINE = "engine/";
$SITE = "site/";
$TASKLIST = "GLOBALS";
$dbConnect = 1;
$dbserver ="localhost" ;
$dbuser ="root";
$dbpass ="password1";
$dbname ="dpm_maindb_new";
$logopath = "site/img/logo/";
$uploadpath = "site/upload/";
$rootpath = "/var/www/dpm5";
?>
